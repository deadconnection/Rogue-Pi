if (self.CavalryLogger) { CavalryLogger.start_js(["eIl1k"]); }

__d("RegistrationNameSuggestionEvents",[],(function(a,b,c,d,e,f){e.exports=Object.freeze({NAMES_SUGGESTED:"names_suggested",NO_NAME_SUGGESTIONS_FOUND:"no_names_suggested",NAME_SUGGESTION_SELECTED:"name_suggestion_selected",NAME_SUGGESTIONS_SKIPPED:"name_suggestions_skipped",NAME_MANUALLY_FIXED:"name_maually_fixed"})}),null);