if (self.CavalryLogger) { CavalryLogger.start_js(["wxy8g"]); }

__d("ZeroClientAutoConfParam",[],(function(a,b,c,d,e,f){e.exports=Object.freeze({FB_JIO_MSISDN_VALUE:"fb_jio_msisdn_value",FB_JIO_MSISDN_TIMESTAMP:"fb_jio_msisdn_timestamp",FB_JIO_MSISDN_SIGNATURE:"fb_jio_msisdn_signature",FB_JIO_MSISDN_SALT:"fb_jio_msisdn_salt"})}),null);