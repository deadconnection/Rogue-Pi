if (self.CavalryLogger) { CavalryLogger.start_js(["50Xky"]); }

__d("KaiOSLoggerEventCategory",[],(function(a,b,c,d,e,f){e.exports=Object.freeze({APP_INFO:"app_info",UPSELL:"upsell",PUSH_SUBSCRIPTION:"push_subscription"})}),null);